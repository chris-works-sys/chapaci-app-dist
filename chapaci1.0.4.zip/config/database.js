import Database from 'better-sqlite3';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';
// Caminho real do diretório atual
const __dirname = path.dirname(fileURLToPath(import.meta.url));
// Caminho do banco
const databasePath = process.env.DATABASE_PATH || 'data';
const fullDatabasePath = path.resolve(__dirname, databasePath);
// Garante que a pasta exista
if (!fs.existsSync(fullDatabasePath)) {
    fs.mkdirSync(fullDatabasePath, { recursive: true });
}
const dbPath = path.join(fullDatabasePath, 'chapaci.db');
console.log(`Usando banco de dados em: ${dbPath}`);
export const db = new Database(dbPath);
// Habilitar Foreign Keys
db.pragma('foreign_keys = ON');
export function initDatabase() {
    db.exec(`
        CREATE TABLE IF NOT EXISTS calls (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            patient_name TEXT NOT NULL,
            location TEXT NOT NULL,
            doctor_name TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        );

        CREATE INDEX IF NOT EXISTS idx_calls_created_at ON calls(created_at DESC);
    `);
}
export function closeDatabase() {
    db.close();
}
//# sourceMappingURL=database.js.map