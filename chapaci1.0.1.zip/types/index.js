import { z } from 'zod';
// Schema de validação para criação de chamada
export const createCallSchema = z.object({
    patient_name: z.string().min(1, 'Nome do paciente é obrigatório'),
    location: z.string().min(1, 'Local é obrigatório'),
    doctor_name: z.string().optional(),
});
//# sourceMappingURL=index.js.map