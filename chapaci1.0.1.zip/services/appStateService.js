/**
 * Gerencia o estado da aplicação
 */
export class AppStateService {
    state = {
        isEnabled: true,
        callIntervalEnabled: true,
        lastCallTime: null,
    };
    /**
     * Obtém o estado atual da aplicação
     */
    getState() {
        return { ...this.state };
    }
    /**
     * Habilita ou desabilita a aplicação
     */
    setEnabled(enabled) {
        this.state.isEnabled = enabled;
    }
    /**
     * Verifica se a aplicação está habilitada
     */
    isEnabled() {
        return this.state.isEnabled;
    }
    /**
     * Habilita ou desabilita o intervalo entre chamadas
     */
    setCallIntervalEnabled(enabled) {
        this.state.callIntervalEnabled = enabled;
    }
    /**
     * Verifica se o intervalo entre chamadas está habilitado
     */
    isCallIntervalEnabled() {
        return this.state.callIntervalEnabled;
    }
    /**
     * Verifica se pode fazer uma nova chamada (respeitando o intervalo de 10 segundos)
     */
    canMakeCall() {
        if (!this.state.callIntervalEnabled) {
            return { allowed: true };
        }
        if (this.state.lastCallTime === null) {
            return { allowed: true };
        }
        const now = Date.now();
        const timeSinceLastCall = now - this.state.lastCallTime;
        const INTERVAL_MS = 10000; // 10 segundos
        if (timeSinceLastCall >= INTERVAL_MS) {
            return { allowed: true };
        }
        const waitTime = Math.ceil((INTERVAL_MS - timeSinceLastCall) / 1000);
        return { allowed: false, waitTime };
    }
    /**
     * Registra o momento de uma nova chamada
     */
    registerCall() {
        this.state.lastCallTime = Date.now();
    }
    /**
     * Reseta o tempo da última chamada
     */
    resetLastCallTime() {
        this.state.lastCallTime = null;
    }
}
//# sourceMappingURL=appStateService.js.map