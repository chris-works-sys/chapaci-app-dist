import { createCallSchema } from '../types/index.js';
import { ZodError } from 'zod';
export async function callRoutes(fastify, callService, appStateService, sseService) {
    /**
     * POST /api/calls
     * Cria uma nova chamada de paciente
     */
    fastify.post('/api/calls', async (request, reply) => {
        try {
            // Verifica se a aplicação está habilitada
            if (!appStateService.isEnabled()) {
                return reply.status(503).send({
                    error: 'Aplicação desabilitada',
                    message: 'O sistema de chamadas está temporariamente desabilitado',
                });
            }
            // Verifica o intervalo entre chamadas
            const callCheck = appStateService.canMakeCall();
            if (!callCheck.allowed) {
                return reply.status(429).send({
                    error: 'Chamada muito rápida',
                    message: `Por favor, aguarde ${callCheck.waitTime} segundos antes de fazer outra chamada`,
                    waitTime: callCheck.waitTime,
                });
            }
            // Valida os dados de entrada
            const data = createCallSchema.parse(request.body);
            // Cria a chamada
            const call = callService.createCall(data);
            // Registra o momento da chamada
            appStateService.registerCall();
            // Notifica clientes SSE
            sseService.notifyNewCall(call);
            return reply.status(201).send({
                success: true,
                data: call,
            });
        }
        catch (error) {
            if (error instanceof ZodError) {
                return reply.status(400).send({
                    error: 'Dados inválidos',
                    details: error.issues,
                });
            }
            fastify.log.error(error);
            return reply.status(500).send({
                error: 'Erro interno do servidor',
            });
        }
    });
    /**
     * GET /api/calls/recent
     * Obtém as chamadas recentes
     */
    fastify.get('/api/calls/recent', async (request, reply) => {
        try {
            const { limit } = request.query;
            const limitNum = limit ? parseInt(limit, 10) : 10;
            if (isNaN(limitNum) || limitNum < 1 || limitNum > 100) {
                return reply.status(400).send({
                    error: 'Limite inválido',
                    message: 'O limite deve ser um número entre 1 e 100',
                });
            }
            const calls = callService.getRecentCalls(limitNum);
            return reply.send({
                success: true,
                count: calls.length,
                data: calls,
            });
        }
        catch (error) {
            fastify.log.error(error);
            return reply.status(500).send({
                error: 'Erro interno do servidor',
            });
        }
    });
    /**
     * GET /api/calls
     * Obtém todas as chamadas
     */
    fastify.get('/api/calls', async (request, reply) => {
        try {
            const calls = callService.getAllCalls();
            return reply.send({
                success: true,
                count: calls.length,
                data: calls,
            });
        }
        catch (error) {
            fastify.log.error(error);
            return reply.status(500).send({
                error: 'Erro interno do servidor',
            });
        }
    });
}
//# sourceMappingURL=callRoutes.js.map