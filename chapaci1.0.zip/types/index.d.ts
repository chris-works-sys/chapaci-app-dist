import { z } from 'zod';
export declare const createCallSchema: z.ZodObject<{
    patient_name: z.ZodString;
    location: z.ZodString;
    doctor_name: z.ZodOptional<z.ZodString>;
}, z.core.$strip>;
export type CreateCallInput = z.infer<typeof createCallSchema>;
export interface Call {
    id: number;
    patient_name: string;
    location: string;
    doctor_name: string | null;
    created_at: string;
}
export interface AppState {
    isEnabled: boolean;
    callIntervalEnabled: boolean;
    lastCallTime: number | null;
}
//# sourceMappingURL=index.d.ts.map