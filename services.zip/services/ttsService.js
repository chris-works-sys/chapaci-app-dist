import { EdgeTTS } from '@andresaya/edge-tts';
import { PassThrough } from 'stream';
/**
 * Serviço de Text-to-Speech (TTS) usando Edge TTS
 * Converte texto em áudio MP3 e retorna um stream Readable (PassThrough)
 */
export class TTSService {
    tts;
    constructor() {
        this.tts = new EdgeTTS();
    }
    /**
     * Gera áudio MP3 a partir de texto
     * @param text - Texto a ser convertido em áudio
     * @param language - Código do idioma/locale (opcional, ex: 'pt-BR' ou 'en-US')
     * @returns Stream de áudio MP3
     */
    generateAudio(text, language) {
        const stream = new PassThrough();
        (async () => {
            try {
                // Seleciona uma voz baseada no locale (se possível)
                let voiceName = undefined;
                if (language) {
                    // Normaliza formatos simples como 'pt-br' -> 'pt-BR'
                    const parts = language.split('-');
                    if (parts.length === 2) {
                        const locale = `${parts[0].toLowerCase()}-${parts[1].toUpperCase()}`;
                        try {
                            const voices = await this.tts.getVoicesByLanguage(locale);
                            if (voices && voices.length > 0) {
                                voiceName = voices[0].ShortName;
                            }
                        }
                        catch (e) {
                            // fallback: tentar apenas a linguagem sem região
                            try {
                                const voices2 = await this.tts.getVoicesByLanguage(parts[0]);
                                if (voices2 && voices2.length > 0) {
                                    voiceName = voices2[0].ShortName;
                                }
                            }
                            catch (err) {
                                // ignore, keep undefined
                            }
                        }
                    }
                    else {
                        try {
                            const voices = await this.tts.getVoicesByLanguage(language);
                            if (voices && voices.length > 0) {
                                voiceName = voices[0].ShortName;
                            }
                        }
                        catch (e) {
                            // ignore and let EdgeTTS pick a default voice
                        }
                    }
                }
                // Consome o async-iterable e escreve no stream
                for await (const chunk of this.tts.synthesizeStream(text, voiceName, {
                    rate: '-10%'
                })) {
                    const ok = stream.write(chunk);
                    if (!ok) {
                        // backpressure: aguarda o drain
                        await new Promise((resolve) => stream.once('drain', () => resolve()));
                    }
                }
                stream.end();
            }
            catch (error) {
                // Propaga o erro no stream
                stream.destroy(error);
            }
        })();
        return stream;
    }
    /**
     * Valida se o texto é válido para geração de áudio
     * @param text - Texto a ser validado
     * @returns true se válido, false caso contrário
     */
    isValidText(text) {
        if (!text || typeof text !== 'string') {
            return false;
        }
        const trimmed = text.trim();
        return trimmed.length > 0 && trimmed.length <= 10000; // permite textos maiores por streaming
    }
}
//# sourceMappingURL=ttsService.js.map