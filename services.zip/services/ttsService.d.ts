import { PassThrough } from 'stream';
/**
 * Serviço de Text-to-Speech (TTS) usando Edge TTS
 * Converte texto em áudio MP3 e retorna um stream Readable (PassThrough)
 */
export declare class TTSService {
    private tts;
    constructor();
    /**
     * Gera áudio MP3 a partir de texto
     * @param text - Texto a ser convertido em áudio
     * @param language - Código do idioma/locale (opcional, ex: 'pt-BR' ou 'en-US')
     * @returns Stream de áudio MP3
     */
    generateAudio(text: string, language?: string): PassThrough;
    /**
     * Valida se o texto é válido para geração de áudio
     * @param text - Texto a ser validado
     * @returns true se válido, false caso contrário
     */
    isValidText(text: string): boolean;
}
//# sourceMappingURL=ttsService.d.ts.map