import type { FastifyInstance } from 'fastify';
import { TTSService } from '../services/ttsService.js';
export declare function ttsRoutes(fastify: FastifyInstance, ttsService: TTSService): Promise<void>;
//# sourceMappingURL=ttsRoutes.d.ts.map