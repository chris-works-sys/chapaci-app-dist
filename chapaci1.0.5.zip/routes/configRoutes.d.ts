import type { FastifyInstance } from 'fastify';
import { AppStateService } from '../services/appStateService.js';
import { SSEService } from '../services/sseService.js';
export declare function configRoutes(fastify: FastifyInstance, appStateService: AppStateService, sseService: SSEService): Promise<void>;
//# sourceMappingURL=configRoutes.d.ts.map