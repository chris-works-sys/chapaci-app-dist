import { z } from 'zod';
// Schema de validação para TTS
const ttsSchema = z.object({
    text: z.string().min(1, 'Texto é obrigatório').max(1000, 'Texto muito longo (máximo 1000 caracteres)'),
    language: z.string().optional().default('pt-br'),
});
export async function ttsRoutes(fastify, ttsService) {
    /**
     * POST /api/tts
     * Converte texto em áudio MP3
     *
     * Body:
     * {
     *   "text": "Paciente João Silva, apresentar na recepção",
     *   "language": "pt-br" (opcional, padrão: pt-br)
     * }
     *
     * Response: Audio MP3 em stream
     */
    fastify.post('/api/tts', async (request, reply) => {
        try {
            // Valida os dados de entrada
            const data = ttsSchema.parse(request.body);
            // Obtém o stream de áudio
            const audioStream = ttsService.generateAudio(data.text, data.language);
            // Configura o header apropriado para MP3
            await reply
                .header('Content-Type', 'audio/mpeg')
                .header('Content-Disposition', 'inline; filename="audio.mp3"')
                .send(audioStream);
        }
        catch (error) {
            if (error instanceof z.ZodError) {
                return reply.status(400).send({
                    error: 'Dados inválidos',
                    details: error.issues,
                });
            }
            fastify.log.error(error);
            return reply.status(500).send({
                error: 'Erro ao gerar áudio',
                message: 'Não foi possível converter o texto em áudio',
            });
        }
    });
}
//# sourceMappingURL=ttsRoutes.js.map