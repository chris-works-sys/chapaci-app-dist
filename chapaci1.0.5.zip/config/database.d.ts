import type BetterSqlite3 from 'better-sqlite3';
export declare const db: BetterSqlite3.Database;
export declare function initDatabase(): void;
export declare function closeDatabase(): void;
//# sourceMappingURL=database.d.ts.map