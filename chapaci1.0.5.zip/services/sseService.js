/**
 * Gerencia conexões Server-Sent Events (SSE)
 */
export class SSEService {
    clients = new Map();
    /**
     * Adiciona um novo cliente SSE
     */
    addClient(id, reply) {
        reply.raw.writeHead(200, {
            'Content-Type': 'text/event-stream',
            'Cache-Control': 'no-cache',
            'Connection': 'keep-alive',
            'Access-Control-Allow-Origin': '*',
        });
        reply.raw.write('\n');
        this.clients.set(id, { id, reply });
        // Envia um evento inicial de conexão
        this.sendToClient(id, { type: 'connected', message: 'Conectado ao servidor' });
        // Remove o cliente quando a conexão é fechada
        reply.raw.on('close', () => {
            this.removeClient(id);
        });
    }
    /**
     * Remove um cliente SSE
     */
    removeClient(id) {
        const client = this.clients.get(id);
        if (client) {
            try {
                client.reply.raw.end();
            }
            catch (error) {
                // Ignora erros ao fechar a conexão
            }
            this.clients.delete(id);
        }
    }
    /**
     * Envia dados para um cliente específico
     */
    sendToClient(id, data) {
        const client = this.clients.get(id);
        if (!client)
            return false;
        try {
            const message = `data: ${JSON.stringify(data)}\n\n`;
            client.reply.raw.write(message);
            return true;
        }
        catch (error) {
            this.removeClient(id);
            return false;
        }
    }
    /**
     * Envia dados para todos os clientes conectados
     */
    broadcast(data) {
        const message = `data: ${JSON.stringify(data)}\n\n`;
        this.clients.forEach((client, id) => {
            try {
                client.reply.raw.write(message);
            }
            catch (error) {
                this.removeClient(id);
            }
        });
    }
    /**
     * Notifica todos os clientes sobre uma nova chamada
     */
    notifyNewCall(call) {
        this.broadcast({
            type: 'new_call',
            data: call,
        });
    }
    /**
     * Obtém o número de clientes conectados
     */
    getClientCount() {
        return this.clients.size;
    }
    /**
     * Desconecta todos os clientes
     */
    disconnectAll() {
        this.clients.forEach((_, id) => {
            this.removeClient(id);
        });
    }
}
//# sourceMappingURL=sseService.js.map