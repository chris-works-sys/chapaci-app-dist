import type { Call, CreateCallInput } from '../types/index.js';
export declare class CallService {
    /**
     * Cria uma nova chamada de paciente
     */
    createCall(data: CreateCallInput): Call;
    /**
     * Busca uma chamada por ID
     */
    getCallById(id: number): Call | undefined;
    /**
     * Busca as chamadas recentes do dia de hoje (últimas N chamadas)
     */
    getRecentCalls(limit?: number): Call[];
    /**
     * Busca todas as chamadas
     */
    getAllCalls(): Call[];
    /**
     * Deleta uma chamada por ID
     */
    deleteCall(id: number): boolean;
}
//# sourceMappingURL=callService.d.ts.map