import gtts from 'node-gtts';
import { PassThrough } from 'stream';
/**
 * Serviço de Text-to-Speech (TTS)
 * Converte texto em áudio MP3 usando Google Text-to-Speech
 */
export class TTSService {
    /**
     * Gera áudio MP3 a partir de texto
     * @param text - Texto a ser convertido em áudio
     * @param language - Código do idioma (padrão: pt-br)
     * @returns Stream de áudio MP3
     */
    generateAudio(text, language = 'pt-br') {
        const ttsInstance = gtts(language);
        const stream = new PassThrough();
        ttsInstance
            .stream(text)
            .pipe(stream)
            .on('error', (error) => {
            stream.destroy(error);
        });
        return stream;
    }
    /**
     * Valida se o texto é válido para geração de áudio
     * @param text - Texto a ser validado
     * @returns true se válido, false caso contrário
     */
    isValidText(text) {
        if (!text || typeof text !== 'string') {
            return false;
        }
        const trimmed = text.trim();
        return trimmed.length > 0 && trimmed.length <= 1000;
    }
}
//# sourceMappingURL=ttsService.js.map