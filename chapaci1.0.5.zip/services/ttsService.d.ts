import { PassThrough } from 'stream';
/**
 * Serviço de Text-to-Speech (TTS)
 * Converte texto em áudio MP3 usando Google Text-to-Speech
 */
export declare class TTSService {
    /**
     * Gera áudio MP3 a partir de texto
     * @param text - Texto a ser convertido em áudio
     * @param language - Código do idioma (padrão: pt-br)
     * @returns Stream de áudio MP3
     */
    generateAudio(text: string, language?: string): PassThrough;
    /**
     * Valida se o texto é válido para geração de áudio
     * @param text - Texto a ser validado
     * @returns true se válido, false caso contrário
     */
    isValidText(text: string): boolean;
}
//# sourceMappingURL=ttsService.d.ts.map