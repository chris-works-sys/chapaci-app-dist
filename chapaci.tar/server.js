import Fastify from 'fastify';
import path from 'path';
import fastifyStatic from '@fastify/static';
import fastifyCors from '@fastify/cors';
import { initDatabase, closeDatabase } from './config/database.js';
import { CallService } from './services/callService.js';
import { AppStateService } from './services/appStateService.js';
import { SSEService } from './services/sseService.js';
import { callRoutes } from './routes/callRoutes.js';
import { sseRoutes } from './routes/sseRoutes.js';
import { configRoutes } from './routes/configRoutes.js';
import { fileURLToPath } from 'url';
// Inicializa o Fastify
const fastify = Fastify({
    logger: {
        level: 'info',
        transport: {
            target: 'pino-pretty',
            options: {
                translateTime: 'HH:MM:ss Z',
                ignore: 'pid,hostname',
            },
        },
    },
});
// Configuração do dirname para ES Modules
const __filename = fileURLToPath(import.meta.url);
const dirname = path.dirname(__filename);
console.log(`__dirname: ${dirname}`);
// Registra plugins
await fastify.register(fastifyCors, {
    origin: '*',
    methods: ['GET', 'POST', 'PUT', 'DELETE'],
});
await fastify.register(fastifyStatic, {
    root: path.join(dirname, 'public'),
    prefix: '/',
});
// Inicializa serviços
const callService = new CallService();
const appStateService = new AppStateService();
const sseService = new SSEService();
// Registra rotas
await callRoutes(fastify, callService, appStateService, sseService);
await sseRoutes(fastify, sseService);
await configRoutes(fastify, appStateService, sseService);
// Rota para servir o frontend
fastify.get('/', (_, reply) => {
    return reply.sendFile('index.html');
});
fastify.get('/tela-chamada', (_, reply) => {
    return reply.sendFile('tela-chamada/index.html');
});
// Função para iniciar o servidor
export async function startServer() {
    try {
        // Inicializa o banco de dados
        initDatabase();
        fastify.log.info('Banco de dados inicializado');
        // Inicia o servidor
        const port = Number(process.env.PORT) || 3000;
        await fastify.listen({ port, host: '0.0.0.0' });
        fastify.log.info(`🚀 Servidor rodando em http://localhost:${port}`);
        fastify.log.info('📊 Documentação da API disponível em http://localhost:${port}');
    }
    catch (err) {
        fastify.log.error(err);
        process.exit(1);
    }
}
// Tratamento de encerramento gracioso
const gracefulShutdown = async () => {
    fastify.log.info('Encerrando servidor...');
    // Desconecta clientes SSE
    sseService.disconnectAll();
    // Fecha o banco de dados
    closeDatabase();
    // Para o servidor
    await fastify.close();
    process.exit(0);
};
process.on('SIGINT', gracefulShutdown);
process.on('SIGTERM', gracefulShutdown);
export { fastify };
//# sourceMappingURL=server.js.map