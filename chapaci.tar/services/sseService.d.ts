import type { FastifyReply } from 'fastify';
import type { Call } from '../types/index.js';
/**
 * Gerencia conexões Server-Sent Events (SSE)
 */
export declare class SSEService {
    private clients;
    /**
     * Adiciona um novo cliente SSE
     */
    addClient(id: string, reply: FastifyReply): void;
    /**
     * Remove um cliente SSE
     */
    removeClient(id: string): void;
    /**
     * Envia dados para um cliente específico
     */
    sendToClient(id: string, data: any): boolean;
    /**
     * Envia dados para todos os clientes conectados
     */
    broadcast(data: any): void;
    /**
     * Notifica todos os clientes sobre uma nova chamada
     */
    notifyNewCall(call: Call): void;
    /**
     * Obtém o número de clientes conectados
     */
    getClientCount(): number;
    /**
     * Desconecta todos os clientes
     */
    disconnectAll(): void;
}
//# sourceMappingURL=sseService.d.ts.map