import { db } from '../config/database.js';
export class CallService {
    /**
     * Cria uma nova chamada de paciente
     */
    createCall(data) {
        const stmt = db.prepare(`
			INSERT INTO calls (patient_name, location, doctor_name)
			VALUES (?, ?, ?)
		`);
        const result = stmt.run(data.patient_name, data.location, data.doctor_name || null);
        return this.getCallById(result.lastInsertRowid);
    }
    /**
     * Busca uma chamada por ID
     */
    getCallById(id) {
        const stmt = db.prepare('SELECT * FROM calls WHERE id = ?');
        return stmt.get(id);
    }
    /**
     * Busca as chamadas recentes (últimas N chamadas)
     */
    getRecentCalls(limit = 10) {
        const stmt = db.prepare(`
			SELECT * FROM calls
			ORDER BY created_at DESC
			LIMIT ?
		`);
        return stmt.all(limit);
    }
    /**
     * Busca todas as chamadas
     */
    getAllCalls() {
        const stmt = db.prepare('SELECT * FROM calls ORDER BY created_at DESC');
        return stmt.all();
    }
    /**
     * Deleta uma chamada por ID
     */
    deleteCall(id) {
        const stmt = db.prepare('DELETE FROM calls WHERE id = ?');
        const result = stmt.run(id);
        return result.changes > 0;
    }
}
//# sourceMappingURL=callService.js.map