import type { AppState } from '../types/index.js';
/**
 * Gerencia o estado da aplicação
 */
export declare class AppStateService {
    private state;
    /**
     * Obtém o estado atual da aplicação
     */
    getState(): AppState;
    /**
     * Habilita ou desabilita a aplicação
     */
    setEnabled(enabled: boolean): void;
    /**
     * Verifica se a aplicação está habilitada
     */
    isEnabled(): boolean;
    /**
     * Habilita ou desabilita o intervalo entre chamadas
     */
    setCallIntervalEnabled(enabled: boolean): void;
    /**
     * Verifica se o intervalo entre chamadas está habilitado
     */
    isCallIntervalEnabled(): boolean;
    /**
     * Verifica se pode fazer uma nova chamada (respeitando o intervalo de 10 segundos)
     */
    canMakeCall(): {
        allowed: boolean;
        waitTime?: number;
    };
    /**
     * Registra o momento de uma nova chamada
     */
    registerCall(): void;
    /**
     * Reseta o tempo da última chamada
     */
    resetLastCallTime(): void;
}
//# sourceMappingURL=appStateService.d.ts.map