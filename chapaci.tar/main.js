import { startServer } from './server.js';
startServer();
//# sourceMappingURL=main.js.map