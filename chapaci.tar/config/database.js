import Database from 'better-sqlite3';
import path from 'path';
const dbPath = path.join(process.cwd(), 'data', 'chapaci.db');
export const db = new Database(dbPath);
// Habilitar Foreign Keys
db.pragma('foreign_keys = ON');
// Criar tabelas
export function initDatabase() {
    db.exec(`
		CREATE TABLE IF NOT EXISTS calls (
			id INTEGER PRIMARY KEY AUTOINCREMENT,
			patient_name TEXT NOT NULL,
			location TEXT NOT NULL,
			doctor_name TEXT,
			created_at DATETIME DEFAULT CURRENT_TIMESTAMP
		);

		CREATE INDEX IF NOT EXISTS idx_calls_created_at ON calls(created_at DESC);
	`);
}
export function closeDatabase() {
    db.close();
}
//# sourceMappingURL=database.js.map