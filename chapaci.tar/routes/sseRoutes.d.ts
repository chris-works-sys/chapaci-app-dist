import type { FastifyInstance } from 'fastify';
import { SSEService } from '../services/sseService.js';
export declare function sseRoutes(fastify: FastifyInstance, sseService: SSEService): Promise<void>;
//# sourceMappingURL=sseRoutes.d.ts.map