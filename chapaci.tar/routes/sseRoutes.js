import { randomUUID } from 'crypto';
export async function sseRoutes(fastify, sseService) {
    /**
     * GET /api/stream
     * Estabelece uma conexão SSE para receber atualizações em tempo real
     */
    fastify.get('/api/stream', async (request, reply) => {
        const clientId = randomUUID();
        fastify.log.info(`Cliente SSE conectado: ${clientId}`);
        sseService.addClient(clientId, reply);
        // Mantém a conexão aberta
        return reply;
    });
    /**
     * GET /api/stream/status
     * Obtém informações sobre conexões SSE ativas
     */
    fastify.get('/api/stream/status', async (request, reply) => {
        return reply.send({
            success: true,
            connectedClients: sseService.getClientCount(),
        });
    });
}
//# sourceMappingURL=sseRoutes.js.map