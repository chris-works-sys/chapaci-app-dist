export async function configRoutes(fastify, appStateService, sseService) {
    /**
     * GET /api/config/status
     * Obtém o estado atual da aplicação
     */
    fastify.get('/api/config/status', async (request, reply) => {
        const state = appStateService.getState();
        return reply.send({
            success: true,
            data: state,
        });
    });
    /**
     * POST /api/config/enable
     * Habilita ou desabilita a aplicação
     */
    fastify.post('/api/config/enable', async (request, reply) => {
        try {
            const { enabled } = request.body;
            if (typeof enabled !== 'boolean') {
                return reply.status(400).send({
                    error: 'Dados inválidos',
                    message: 'O campo "enabled" deve ser um booleano',
                });
            }
            appStateService.setEnabled(enabled);
            // Notifica clientes SSE sobre mudança de estado
            sseService.broadcast({
                type: 'app_state_changed',
                data: {
                    isEnabled: enabled,
                },
            });
            return reply.send({
                success: true,
                message: enabled ? 'Aplicação habilitada' : 'Aplicação desabilitada',
                data: appStateService.getState(),
            });
        }
        catch (error) {
            fastify.log.error(error);
            return reply.status(500).send({
                error: 'Erro interno do servidor',
            });
        }
    });
    /**
     * POST /api/config/call-interval
     * Habilita ou desabilita o intervalo entre chamadas
     */
    fastify.post('/api/config/call-interval', async (request, reply) => {
        try {
            const { enabled } = request.body;
            if (typeof enabled !== 'boolean') {
                return reply.status(400).send({
                    error: 'Dados inválidos',
                    message: 'O campo "enabled" deve ser um booleano',
                });
            }
            appStateService.setCallIntervalEnabled(enabled);
            // Se desabilitar, reseta o tempo da última chamada
            if (!enabled) {
                appStateService.resetLastCallTime();
            }
            // Notifica clientes SSE
            sseService.broadcast({
                type: 'interval_state_changed',
                data: {
                    callIntervalEnabled: enabled,
                },
            });
            return reply.send({
                success: true,
                message: enabled
                    ? 'Intervalo entre chamadas habilitado'
                    : 'Intervalo entre chamadas desabilitado',
                data: appStateService.getState(),
            });
        }
        catch (error) {
            fastify.log.error(error);
            return reply.status(500).send({
                error: 'Erro interno do servidor',
            });
        }
    });
}
//# sourceMappingURL=configRoutes.js.map