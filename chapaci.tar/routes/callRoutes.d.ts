import type { FastifyInstance } from 'fastify';
import { CallService } from '../services/callService.js';
import { AppStateService } from '../services/appStateService.js';
import { SSEService } from '../services/sseService.js';
export declare function callRoutes(fastify: FastifyInstance, callService: CallService, appStateService: AppStateService, sseService: SSEService): Promise<void>;
//# sourceMappingURL=callRoutes.d.ts.map